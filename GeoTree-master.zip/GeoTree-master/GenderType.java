public enum GenderType {
    male, female
}
